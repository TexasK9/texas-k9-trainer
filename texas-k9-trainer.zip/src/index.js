
import React from 'react';
import ReactDOM from 'react-dom';
import TrainerApp from './App';
import * as serviceWorkerRegistration from './serviceWorkerRegistration';

ReactDOM.render(
  <React.StrictMode>
    <TrainerApp />
  </React.StrictMode>,
  document.getElementById('root')
);

serviceWorkerRegistration.register();
