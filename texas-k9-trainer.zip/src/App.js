
import React, { useState, useEffect } from 'react';

function TrainerApp() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [notes, setNotes] = useState('');
  const [progress, setProgress] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const savedNotes = localStorage.getItem('trainer_notes');
    const savedProgress = localStorage.getItem('trainer_progress');
    if (savedNotes) setNotes(savedNotes);
    if (savedProgress) setProgress(savedProgress);
  }, []);

  useEffect(() => {
    localStorage.setItem('trainer_notes', notes);
  }, [notes]);

  useEffect(() => {
    localStorage.setItem('trainer_progress', progress);
  }, [progress]);

  return (
    <div style={{ padding: 16, fontFamily: 'Arial' }}>
      <h1 style={{ fontSize: 24, fontWeight: 'bold' }}>Texas K9 Companion Trainer</h1>
      <div style={{ marginTop: 20 }}>
        <h2>Calendar</h2>
        <button onClick={() => setSelectedDate(new Date())}>
          Today: {selectedDate.toDateString()}
        </button>
      </div>
      <div style={{ marginTop: 20 }}>
        <h2>Lesson Plan</h2>
        <p><strong>Weekly Focus:</strong> Relationship Building</p>
        <ul>
          <li>Engage in eye contact for 10 seconds</li>
          <li>Hand-feed meals to build engagement</li>
          <li>Reward calm behavior with praise or treats</li>
        </ul>
        <p><i>Tip: Trust builds in the small moments.</i></p>
      </div>
      <div style={{ marginTop: 20 }}>
        <h2>Behavior Decoder</h2>
        <input
          placeholder="Search behavior"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{ width: '100%', padding: 8 }}
        />
        <p>{searchTerm ? `${searchTerm}: explanation goes here.` : 'Example: Lip Licking – a sign of stress.'}</p>
      </div>
      <div style={{ marginTop: 20 }}>
        <h2>Training Journal</h2>
        <textarea
          placeholder="Notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          style={{ width: '100%', height: 80 }}
        />
        <textarea
          placeholder="Progress"
          value={progress}
          onChange={(e) => setProgress(e.target.value)}
          style={{ width: '100%', height: 80, marginTop: 8 }}
        />
      </div>
    </div>
  );
}

export default TrainerApp;
